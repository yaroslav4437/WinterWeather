package ru.winterweather;

import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Monster;
import org.bukkit.entity.PolarBear;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class WinterWeather extends JavaPlugin implements Listener {
    private enum Weather { NONE, SNOW, HAIL }

    private static final int DURATION_SECONDS = 300;
    private static final int WARNING_SECONDS = 5;
    private Weather activeWeather = Weather.NONE;
    private int secondsLeft;
    private final Random random = new Random();
    private BossBar bossBar;
    private BukkitTask weatherTask;
    private BukkitTask warningTask;
    private BukkitTask bearTask;
    private final Set<UUID> spawnedBears = new HashSet<>();
    private final Map<World, WorldSnapshot> snapshots = new HashMap<>();
    private final Map<Player, Integer> coldSeconds = new HashMap<>();
    private final Map<Player, Boolean> darknessApplied = new HashMap<>();
    private final java.util.Set<Location> placedSnow = new java.util.HashSet<>();
    private int elapsedSeconds;

    private record WorldSnapshot(boolean storm, boolean thunder, long time,
                                 boolean daylightCycle, boolean mobSpawning) {}

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("WinterWeather Bukkit включён.");
    }

    @Override
    public void onDisable() {
        stopWeather();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("w")) return false;
        if (!sender.hasPermission("winterweather.use")) {
            sender.sendMessage("§cУ тебя нет прав!");
            return true;
        }
        if (args.length != 1) {
            sender.sendMessage("§eИспользование: /w 1 — снег, /w 2 — град, /w 0 — выключить");
            return true;
        }
        switch (args[0]) {
            case "1" -> startWarning(Weather.SNOW);
            case "2" -> startWarning(Weather.HAIL);
            case "0" -> {
                stopWeather();
                Bukkit.broadcastMessage("§7Зимняя погода и зимние эффекты выключены.");
            }
            default -> sender.sendMessage("§cВыбери: 0, 1 или 2.");
        }
        return true;
    }

    private void startWarning(Weather weather) {
        stopWeather();
        String kind = weather == Weather.SNOW ? "снегопад" : "град";
        Bukkit.broadcastMessage("§c⚠ УКРОЙТЕСЬ В ЗДАНИЕ! Будет " + kind.toUpperCase() + "!!!");
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendTitle("§c§lУКРОЙТЕСЬ В ЗДАНИЕ!", weather == Weather.SNOW
                    ? "§bСкоро начнётся сильный снегопад!"
                    : "§9Скоро начнётся сильный град!", 5, 80, 10);
        }
        warningTask = Bukkit.getScheduler().runTaskLater(this, () -> {
            warningTask = null;
            beginWeather(weather);
        }, WARNING_SECONDS * 20L);
    }

    private void beginWeather(Weather weather) {
        activeWeather = weather;
        secondsLeft = DURATION_SECONDS;
        elapsedSeconds = 0;
        for (World world : Bukkit.getWorlds()) {
            boolean daylight = Boolean.TRUE.equals(world.getGameRuleValue(GameRule.DO_DAYLIGHT_CYCLE));
            boolean mobs = Boolean.TRUE.equals(world.getGameRuleValue(GameRule.DO_MOB_SPAWNING));
            snapshots.put(world, new WorldSnapshot(world.hasStorm(), world.isThundering(),
                    world.getTime(), daylight, mobs));
            world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
            world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
            world.setTime(18000L);
            world.setStorm(true);
            world.setThundering(weather == Weather.HAIL);
            world.setWeatherDuration(DURATION_SECONDS * 20);
            world.setThunderDuration(DURATION_SECONDS * 20);
            for (var entity : world.getEntities()) {
                if (entity instanceof Monster) entity.remove();
            }
        }

        bossBar = Bukkit.createBossBar("", weather == Weather.SNOW ? BarColor.WHITE : BarColor.BLUE, BarStyle.SOLID);
        bossBar.setVisible(true);
        for (Player player : Bukkit.getOnlinePlayers()) bossBar.addPlayer(player);
        Bukkit.broadcastMessage(weather == Weather.SNOW
                ? "§b❄ Начался МОЩНЫЙ МЕТЕЛЬНЫЙ СНЕГОПАД!"
                : "§9❄ Начался СИЛЬНЫЙ ЛЕДЯНОЙ ГРАД!");
        Bukkit.broadcastMessage("§f🐻 Белые медведи вышли на охоту! Они нападают на игроков.");

        spawnBearsNearPlayers();
        bearTask = Bukkit.getScheduler().runTaskTimer(this, this::spawnBearsNearPlayers, 200L, 600L);

        weatherTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (activeWeather == Weather.NONE) return;
            for (World world : Bukkit.getWorlds()) world.setTime(18000L);
            spawnStormParticles();
            updateColdAndDarkness();
            elapsedSeconds++;
            if (activeWeather == Weather.SNOW && elapsedSeconds % 10 == 0) accumulateSnow();

            secondsLeft--;
            if (bossBar != null) {
                bossBar.setTitle((activeWeather == Weather.SNOW ? "§b❄ Метель закончится через: §f" : "§9❄ Град закончится через: §f")
                        + secondsLeft + " сек.");
                bossBar.setProgress(Math.max(0.0, Math.min(1.0, secondsLeft / (double) DURATION_SECONDS)));
            }
            if (secondsLeft <= 0) {
                stopWeather();
                Bukkit.broadcastMessage("§7Зимняя буря закончилась.");
            }
        }, 0L, 20L);
    }

    // Dense layered particles, with wind drift for a blizzard-like appearance.
    private void spawnStormParticles() {
        BlockData snow = Bukkit.createBlockData(Material.SNOW_BLOCK);
        BlockData powder = Bukkit.createBlockData(Material.POWDER_SNOW);
        BlockData ice = Bukkit.createBlockData(Material.PACKED_ICE);
        BlockData blueIce = Bukkit.createBlockData(Material.BLUE_ICE);
        for (Player player : Bukkit.getOnlinePlayers()) {
            Location loc = player.getLocation();
            World world = player.getWorld();
            int count = activeWeather == Weather.SNOW ? 260 : 190;
            for (int i = 0; i < count; i++) {
                double x = loc.getX() + random.nextDouble() * 42 - 21;
                double z = loc.getZ() + random.nextDouble() * 42 - 21;
                double y = Math.min(world.getMaxHeight() - 1, loc.getY() + 5 + random.nextDouble() * 28);
                if (activeWeather == Weather.SNOW) {
                    world.spawnParticle(Particle.SNOWFLAKE, x, y, z, 2, 0.35, 0.7, 0.35, 0.025);
                    if (i % 3 == 0) world.spawnParticle(Particle.FALLING_DUST, x, y, z, 1, 0.12, 0.3, 0.12, 0, random.nextBoolean() ? snow : powder);
                } else {
                    world.spawnParticle(Particle.BLOCK, x, y, z, 3, 0.22, 0.5, 0.22, 0.12, random.nextBoolean() ? ice : blueIce);
                    if (i % 5 == 0) world.spawnParticle(Particle.SNOWFLAKE, x, y, z, 1, 0.1, 0.2, 0.1, 0.01);
                }
            }
            if (activeWeather == Weather.HAIL && random.nextInt(3) == 0
                    && player.getGameMode() != org.bukkit.GameMode.CREATIVE
                    && player.getGameMode() != org.bukkit.GameMode.SPECTATOR) {
                player.damage(1.0);
                player.sendActionBar("§bЛедяной град бьёт по тебе!");
            }
        }
    }

    // Snow piles rise gradually; by minute 3 the target is four full blocks.
    private void accumulateSnow() {
        int targetHeight = Math.min(4, (int) Math.ceil(elapsedSeconds / 45.0));
        for (Player player : Bukkit.getOnlinePlayers()) {
            World world = player.getWorld();
            int cx = player.getLocation().getBlockX();
            int cz = player.getLocation().getBlockZ();
            // Spread snow over a compact area around each player every 10 seconds.
            for (int dx = -5; dx <= 5; dx++) {
                for (int dz = -5; dz <= 5; dz++) {
                    int x = cx + dx;
                    int z = cz + dz;
                    Block highest = world.getHighestBlockAt(x, z);
                    if (highest.getType().isAir() || highest.isLiquid()) continue;
                    if (highest.getLightFromSky() < 12) continue; // don't bury roofs/interiors
                    int currentSnow = 0;
                    Block ground = highest;
                    while (ground.getType() == Material.SNOW_BLOCK && currentSnow < 4) {
                        currentSnow++;
                        ground = ground.getRelative(BlockFace.DOWN);
                    }
                    if (currentSnow >= targetHeight) continue;
                    Block next = highest.getRelative(BlockFace.UP);
                    if (!next.isEmpty() || next.getY() >= world.getMaxHeight()) continue;
                    next.setType(Material.SNOW_BLOCK, false);
                    placedSnow.add(next.getLocation());
                }
            }
        }
    }

    private void removeAccumulatedSnow() {
        for (Location location : placedSnow) {
            Block block = location.getBlock();
            if (block.getType() == Material.SNOW_BLOCK) block.setType(Material.AIR, false);
        }
        placedSnow.clear();
    }

    private void makePolarBearsAggressive() {
        for (World world : Bukkit.getWorlds()) {
            for (PolarBear bear : world.getEntitiesByClass(PolarBear.class)) {
                Player nearest = null;
                double distance = Double.MAX_VALUE;
                for (Player player : world.getPlayers()) {
                    if (player.getGameMode() == org.bukkit.GameMode.CREATIVE
                            || player.getGameMode() == org.bukkit.GameMode.SPECTATOR) continue;
                    double d = bear.getLocation().distanceSquared(player.getLocation());
                    if (d < distance && d < 30 * 30) { distance = d; nearest = player; }
                }
                if (nearest != null) bear.setTarget(nearest);
            }
        }
    }

    private void spawnAndControlPolarBears() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            World world = player.getWorld();
            // One hostile bear near each player at most, to avoid excessive mob buildup.
            boolean nearbyBear = world.getNearbyEntities(player.getLocation(), 24, 16, 24,
                    entity -> entity instanceof PolarBear).size() > 0;
            if (!nearbyBear && random.nextInt(12) == 0) {
                Location spawn = player.getLocation().clone().add(
                        random.nextInt(25) - 12, 0, random.nextInt(25) - 12);
                spawn.setY(world.getHighestBlockYAt(spawn) + 1);
                if (spawn.getBlock().isPassable()) {
                    PolarBear bear = world.spawn(spawn, PolarBear.class);
                    bear.setAdult();
                    bear.setPersistent(false);
                    bear.setTarget(player);
                    bear.setCustomName("§f§lЗлой белый медведь");
                    bear.setCustomNameVisible(false);
                }
            }
        }
    }

    @EventHandler
    public void onBearAttack(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof PolarBear) {
            event.setDamage(6.0); // 6 health points = 3 hearts
        }
    }

    private void updateColdAndDarkness() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            boolean warm = hasFullLeatherArmor(player) || nearLitCampfire(player);
            if (warm) {
                coldSeconds.put(player, 0);
                player.removePotionEffect(PotionEffectType.SLOWNESS);
                player.removePotionEffect(PotionEffectType.DARKNESS);
                darknessApplied.remove(player);
                player.setFreezeTicks(Math.max(0, player.getFreezeTicks() - 80));
                player.sendActionBar("§6Тебе тепло — костёр или кожаная броня защищают от холода.");
                continue;
            }

            int cold = coldSeconds.getOrDefault(player, 0) + 1;
            coldSeconds.put(player, cold);
            player.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 50, 0, true, false, false));
            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, Math.min(2, cold / 45), true, false, true));
            player.setFreezeTicks(Math.min(player.getMaxFreezeTicks(), player.getFreezeTicks() + 15));

            if (cold < 10) {
                player.sendActionBar("§b❄ Холодно! Надень полную кожаную броню или найди зажжённый костёр.");
            } else if (cold % 5 == 0 && player.getGameMode() != org.bukkit.GameMode.CREATIVE
                    && player.getGameMode() != org.bukkit.GameMode.SPECTATOR) {
                player.damage(1.0);
                player.sendActionBar("§cТы замерзаешь! Срочно согрейся у костра или надень кожаную броню!");
            }
        }
    }

    private boolean hasFullLeatherArmor(Player player) {
        ItemStack[] armor = player.getInventory().getArmorContents();
        if (armor.length < 4) return false;
        for (ItemStack item : armor) {
            if (item == null || item.getType() != Material.LEATHER_HELMET
                    && item.getType() != Material.LEATHER_CHESTPLATE
                    && item.getType() != Material.LEATHER_LEGGINGS
                    && item.getType() != Material.LEATHER_BOOTS) return false;
        }
        return true;
    }

    private boolean nearLitCampfire(Player player) {
        Location center = player.getLocation();
        int radius = 5;
        for (int x = -radius; x <= radius; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -radius; z <= radius; z++) {
                    Block block = center.getBlock().getRelative(x, y, z);
                    if ((block.getType() == Material.CAMPFIRE || block.getType() == Material.SOUL_CAMPFIRE)
                            && block.getBlockData() instanceof org.bukkit.block.data.Lightable lightable
                            && lightable.isLit()) return true;
                }
            }
        }
        return false;
    }


    // Aggressive polar bears spawn around players during the winter event.
    private void spawnBearsNearPlayers() {
        if (activeWeather == Weather.NONE) return;
        for (Player player : Bukkit.getOnlinePlayers()) {
            World world = player.getWorld();
            long inWorld = spawnedBears.stream()
                    .map(Bukkit::getEntity)
                    .filter(entity -> entity instanceof PolarBear && entity.getWorld().equals(world))
                    .count();
            int amount = (int) Math.max(0, Math.min(3, 10 - inWorld));
            for (int i = 0; i < amount; i++) {
                int dx = random.nextInt(41) - 20;
                int dz = random.nextInt(41) - 20;
                if (Math.abs(dx) < 7 && Math.abs(dz) < 7) dx += 10;
                int x = player.getLocation().getBlockX() + dx;
                int z = player.getLocation().getBlockZ() + dz;
                int y = world.getHighestBlockYAt(x, z);
                if (y <= world.getMinHeight() || y >= world.getMaxHeight() - 2) continue;
                Block ground = world.getBlockAt(x, y, z);
                Block feet = world.getBlockAt(x, y + 1, z);
                Block head = world.getBlockAt(x, y + 2, z);
                if (!ground.getType().isSolid() || !feet.isPassable() || !head.isPassable()) continue;

                Location spawnAt = new Location(world, x + 0.5, y + 1, z + 0.5);
                PolarBear bear = world.spawn(spawnAt, PolarBear.class, spawned -> {
                    spawned.setAdult();
                    spawned.setAnger(100000);
                    spawned.setTarget(player);
                    spawned.setCustomName("§f§lДикий белый медведь");
                    spawned.setCustomNameVisible(false);
                });
                spawnedBears.add(bear.getUniqueId());
            }
        }
    }

    @EventHandler
    public void onPolarBearDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof PolarBear bear && spawnedBears.contains(bear.getUniqueId())) {
            event.setDamage(6.0); // 6 health points = 3 hearts
        }
    }

    private void stopWeather() {
        if (warningTask != null) {
            warningTask.cancel();
            warningTask = null;
        }
        if (weatherTask != null) {
            weatherTask.cancel();
            weatherTask = null;
        }
        if (bearTask != null) {
            bearTask.cancel();
            bearTask = null;
        }
        for (UUID id : spawnedBears) {
            Entity entity = Bukkit.getEntity(id);
            if (entity != null && entity.isValid()) entity.remove();
        }
        spawnedBears.clear();
        if (bossBar != null) {
            bossBar.removeAll();
            bossBar.setVisible(false);
            bossBar = null;
        }
        if (activeWeather != Weather.NONE) {
            for (World world : Bukkit.getWorlds()) {
                WorldSnapshot old = snapshots.get(world);
                if (old != null) {
                    world.setStorm(old.storm());
                    world.setThundering(old.thunder());
                    world.setTime(old.time());
                    world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, old.daylightCycle());
                    world.setGameRule(GameRule.DO_MOB_SPAWNING, old.mobSpawning());
                }
            }
            for (Player player : Bukkit.getOnlinePlayers()) {
                player.removePotionEffect(PotionEffectType.DARKNESS);
                player.removePotionEffect(PotionEffectType.SLOWNESS);
                player.setFreezeTicks(0);
            }
        }
        removeAccumulatedSnow();
        snapshots.clear();
        coldSeconds.clear();
        darknessApplied.clear();
        activeWeather = Weather.NONE;
        secondsLeft = 0;
        elapsedSeconds = 0;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (bossBar != null) bossBar.addPlayer(event.getPlayer());
        if (warningTask != null) {
            event.getPlayer().sendTitle("§c§lУКРОЙТЕСЬ В ЗДАНИЕ!", "§eСкоро начнётся зимняя буря!", 5, 80, 10);
        }
    }
}
